public class ArrayTest4 {
    public static void main(String args[]){
        int[] numbers = {10, 20, 30};
        for (int value : numbers)
            System.out.println(value+" ");
    }
}
