public class GetMin {
    public static void main(String args[]){
        int s[] = { 12, 3, 19, 6, 18, 8, 12, 4, 1, 19};
        int minimum;

        minimum = s[0]; // 첫 번째 배열 요소를 최소값으로 가정

        for (int i = 1; i < s.length; i++){ // 배열의 두 번째 요소부터 비교한다.
            if (s[i] < minimum)
                minimum = s[i]; // 현재의 최소값보다 배열 요소가 작으면, 배열 요소를 최소값으로 복사한다.
        }

        System.out.println("최소값은" + minimum + "입니다.");
    }
}
