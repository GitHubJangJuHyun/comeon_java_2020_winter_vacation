public class ArrayTest3 {
    public static void main(String args[]){
        int[] scores = { 10, 20, 30, 40, 50 };
        for (int i = 0; i < scores.length; i++)
            System.out.println(scores[i] + " ");
    }
}
