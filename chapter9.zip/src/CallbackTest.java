import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

class MyClass implements ActionListener{ // ActionListener 인터페이스를 구현한 클래스를 생성한다.
    public void actionPerformed(ActionEvent event){ // Timer에 의하여 1초에 한번씩 호출된다.
        System.out.println("beep");
    }
}

public class CallbackTest {
    public static void main(String args[]){

        ActionListener listener = new MyClass();
        Timer t = new Timer(1000, listener); // actionPerformed()를 호출해달라고 Timer에 등록한다.
        t.start();
        for (int i = 0; i < 1000; i++){
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e){
        }
    } // 1초 동안 잤다가, 깨어나는 동작을 1000번 되풀이한다. 1초에 한번씩 호출되는지를 보기 위하여 반복하는 것이다. 단위는 밀리초이다.
}
}
