package kr.co.company.mylibrary;

public class PackageTest {

    public static void main(String args[]){
        System.out.println("패키지 테스트입니다.");
    }
}
