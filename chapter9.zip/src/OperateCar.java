public interface OperateCar {

    void start();
    void stop();
    void setSpeed(int speed);
    void turn(int degree);
}
