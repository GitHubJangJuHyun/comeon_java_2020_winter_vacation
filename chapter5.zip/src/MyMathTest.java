public class MyMathTest {
    public static void main(String args[]){
        MyMath obj = new MyMath();
        System.out.println(obj.square(10));
        System.out.println(obj.square(3.14));
    }
}
