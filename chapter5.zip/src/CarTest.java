public class CarTest {
    public static void main(String args[]){

        Car myCar = new Car(); // 객체 생성
        myCar.changeGear(1); // 객체의 메소드 호출
        myCar.speedUp(); // toString() 호출
    }
}
