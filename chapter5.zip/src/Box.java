public class Box {
    int width;
    int length;
    int height;
}
