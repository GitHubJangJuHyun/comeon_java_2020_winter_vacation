public class Parent {
    public void print(){
        System.out.println("부모 클래스의 print() 메소드");
    }
}
