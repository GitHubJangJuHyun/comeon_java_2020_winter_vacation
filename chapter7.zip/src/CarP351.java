public class CarP351 {
    private String model;
    public CarP351(String model){
        this.model = model;
    }

    public boolean equals(Object obj){
        if (obj instanceof CarP351)
            return model.equals(((CarP351)obj).model);
        else
            return false;
    }
}
