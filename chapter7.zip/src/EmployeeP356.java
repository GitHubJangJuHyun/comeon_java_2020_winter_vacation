public class EmployeeP356 {
    private String name;
    private DateP355 birthDate;

    public EmployeeP356(String name, DateP355 birthDate){
        this.name = name;
        this.birthDate = birthDate;
    }

    @Override
    public String toString(){
        return "Employee [name=" + name + ", birthDate=" + birthDate
                + "]";
    }
}
