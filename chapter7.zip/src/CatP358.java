public class CatP358 extends AnimalP358{
    public static void eat(){
        System.out.println("Cat의 정적 메소드 eat()");
    }
    public void sound(){
        System.out.println("Cat의 인스턴스 메소드 sound()");
    }
    public static void main(String args[]){
        CatP358 myCat = new CatP358();
        AnimalP358 myAnimal = myCat;
        AnimalP358.eat();
        myAnimal.sound();
    }
}
