public class Dog extends Animal1{
    public void eat(){
        System.out.println("강아지가 먹고 있습니다.");
    }
}
