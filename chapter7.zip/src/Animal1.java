public class Animal1 {
    public void eat(){
        System.out.println("동물이 먹고 있습니다. ");
    }
}
