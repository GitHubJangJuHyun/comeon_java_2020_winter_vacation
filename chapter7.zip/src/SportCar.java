public class SportCar extends Car{
    boolean turbo; // 추가된 필드

    public void setTurbo(boolean flag){ // 터보 모드 설정 메소드
        turbo = flag;
    }
}
