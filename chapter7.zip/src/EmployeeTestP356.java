public class EmployeeTestP356 {
    public static void main(String args[]){
        DateP355 birth = new DateP355(1990, 1, 1);
        EmployeeP356 employee = new EmployeeP356("홍길동", birth);
        System.out.println(employee);
    }
}
