public class SportsCarTest {
    public static void main(String args[]){
        SportCar obj = new SportCar(); // 자식 클래스 객체 생성
        obj.speed = 10;
        obj.setSpeed(60); // 부모 클래스의 필드와 메소드 사용
        obj.setTurbo(true); // 자체 메소드 사용
    }
}
