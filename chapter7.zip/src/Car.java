public class Car {
    int speed; // 속도
    public void setSpeed(int speed){ // 속도 변경 메소드
        this.speed = speed;
    }
}
