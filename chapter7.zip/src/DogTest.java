public class DogTest {
    public static void main(String[] args){
        Dog d = new Dog();
        d.eat();
    }
}
