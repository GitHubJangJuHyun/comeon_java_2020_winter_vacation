public class LabShape {
    private int x;
    private int y;

    public LabShape(int x, int y){
        System.out.println("Shape()");
        this.x = x;
        this.y = y;
    }
}
