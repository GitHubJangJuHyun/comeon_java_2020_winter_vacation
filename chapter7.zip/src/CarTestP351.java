public class CarTestP351 {
    public static void main(String args[]){

        CarP351 firstCar = new CarP351("HMW520");
        CarP351 secondCar = new CarP351("HMW520");
        if (firstCar.equals(secondCar)){
            System.out.println("동일한 종류의 자동차입니다.");
        } else{
            System.out.println("동일한 종류의 자동차가 아닙니다.");
        }
    }
}
