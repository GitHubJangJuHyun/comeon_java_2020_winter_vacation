public class MyCounterTest1 {
    public static void main(String args[]){

        MyCounter1 obj = new MyCounter1();
        int x = 10;

        obj.inc(x);
        System.out.println("x = " + x);
    }
}
