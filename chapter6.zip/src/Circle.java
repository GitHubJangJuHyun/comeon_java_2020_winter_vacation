public class Circle {
    private int radius;
    private LabPoint center;

    public Circle(LabPoint p, int r){
        center = p;
        radius = r;
    }
    @Override
    public String toString(){
        return "Circle [radius=" + radius + ", center=" + center + "]";
    }
}
