public class InnerClassTest {
    public static void main(String args[]){
        OuterClass outer = new OuterClass();
    }
}
