public class LabPoint {
    private int x, y;

    public LabPoint(int a, int b){
        x = a;
        y = b;
    }
    @Override
    public String toString(){
        return "Point [x=" + x + ", y=" + y + "]";
    }
}
