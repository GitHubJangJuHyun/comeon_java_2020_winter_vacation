public class MyCounter1 {
    int value;
    void inc(int a){
        a = a + 1;
    }
}
