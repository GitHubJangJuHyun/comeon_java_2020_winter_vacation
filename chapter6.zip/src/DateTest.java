public class DateTest {
    public static void main(String args[]){
        Date date1 = new Date(2015, "8월", 10);
        Date date2 = new Date(2020);
        Date date3 = new Date();
        System.out.println(date1);
        System.out.println(date2);
        System.out.println(date3);
    }
}
