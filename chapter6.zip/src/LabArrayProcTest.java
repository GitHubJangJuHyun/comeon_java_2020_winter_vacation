public class LabArrayProcTest {
    final static int STUDENTS = 5;

    public static void main(String args[]){
        int[] scores = new int[STUDENTS];
        LabArrayProc obj = new LabArrayProc();
        obj.getValues(scores);
        System.out.println("평균은 = " + obj.getAverage(scores));
    }
}
