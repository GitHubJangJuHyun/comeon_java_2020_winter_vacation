public class Point {
    private int x = 0;
    private int y = 0;

    // 생성자
    public Point(int a, int b){
        this.x = x;
        this.y = y;
    }
}
