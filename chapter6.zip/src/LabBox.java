/*public class LabBox {
    int width, length, height;
    int volume;

    LabBox(int w, int l, int h){
        width = w;
        length = l;
        height = h;
        volume = w * l * h;
    }

    Box whosLargest(LabBox box1, LabBox box2){
        if (box1.volume > box2.volume)
            return box1;
        else
            return box2;
    }
} */
