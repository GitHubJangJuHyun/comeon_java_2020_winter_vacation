public class MyCounter {
    int counter;

    MyCounter(int value){
        counter = value;
    }
}
