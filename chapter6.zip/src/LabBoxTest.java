/* public class LabBoxTest {
    public static void main(String args[]){
        LabBox obj1 = new LabBox(10, 20, 50);
        LabBox obj2 = new LabBox(10, 30, 30);

        LabBox largest = obj1.whosLargest(obj1, obj2);
        System.out.println("(" + largest.width + "," + largest.length
        + "," + largest.height + ")");
    }
} */
