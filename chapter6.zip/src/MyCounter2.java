public class MyCounter2 {
    int value = 0;
    void inc(MyCounter2 ctr){
        ctr.value = ctr.value + 1;
    }
}
