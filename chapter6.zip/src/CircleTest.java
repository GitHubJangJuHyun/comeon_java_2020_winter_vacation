public class CircleTest {
    public static void main(String args[]){
        LabPoint p = new LabPoint(25, 78);
        Circle c = new Circle(p, 10);
        System.out.println(c);
    }
}
