import java.util.Scanner;

public class CalSum{
    public static void main(String args[]){
/*         int i=0;
        int n=0;

        while (i <= 10){
            n = n + i;
            i++;
        }
        System.out.println("합계=" + n); */
        int i = 0;
        int n = 0;
        int sum = 0;
        System.out.println("원하는 수를 입력하시오.");
        Scanner scan = new Scanner(System.in);
        n = scan.nextInt();

        while ( i <= n){
            sum = sum + i;
            i++;
        }
        System.out.println("합계=" + sum);
    }
}
