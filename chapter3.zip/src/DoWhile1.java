public class DoWhile1 {
    public static void main(String args[]){
        int i = 10;
        do {
            System.out.println("i의 값: " + i);
            i++;
        } while (i < 3);
    }
}
