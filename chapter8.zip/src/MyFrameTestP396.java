public class MyFrameTestP396 {
    public static void main(String args[]){
        MyFrameP396 f = new MyFrameP396();
    }
}
