public class MyFrameTestP383 {
    public static void main(String args[]){
        MyFrameP382 f = new MyFrameP382();
    }
}
