public class AbsoluteTestP389 {
    public static void main(String args[]){
        MyFrameP388 f = new MyFrameP388();
    }
}
