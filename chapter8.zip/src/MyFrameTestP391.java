public class MyFrameTestP391 {
    public static void main(String args[]){
        MyFrameP391 f = new MyFrameP391();
    }
}
