public class GridTest {
    public static void main(String args[]){
        MyFrameP386 f = new MyFrameP386();
    }
}
