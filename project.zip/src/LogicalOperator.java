public class LogicalOperator {

    public static void main(String argsp[]){
        int x = 3;
        int y = 4;
        System.out.println((x == 3) && (y == 7));
        System.out.println((x == 3 || y == 4));
    }
}
