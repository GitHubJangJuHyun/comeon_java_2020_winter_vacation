public class VarInitTest {
    public static void main(String args[]){
        int index = 1;

        index = index + 1;
        System.out.println("index : " + index);

    }
}
