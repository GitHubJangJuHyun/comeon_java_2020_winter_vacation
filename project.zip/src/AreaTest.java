public class AreaTest {
    public static void main(String args[]){
        double radius, area;

        radius = 5.0;
        area = 3.141592 * radius * radius;
        System.out.println("원의 면적은 " + area);
    }
}
