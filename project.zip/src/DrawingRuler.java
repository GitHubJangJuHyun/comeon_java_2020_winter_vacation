public class DrawingRuler {
    public static void main(String args[]){
        String s1 = ".........";
        String s2 = s1 + "|" + s1;
        String s3 = s2 + "|" + s2;

        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);
    }
}
