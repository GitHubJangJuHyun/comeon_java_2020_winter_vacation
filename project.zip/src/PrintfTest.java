public class PrintfTest {
    public static void main(String args[]){

        double value = 1.0 / 3.0;
        // System.out.print(value);
        System.out.printf("%1.2f", value);
    }
}
