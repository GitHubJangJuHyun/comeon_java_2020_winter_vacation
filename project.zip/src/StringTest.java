public class StringTest {
    public static void main(String args[]){
        String s1 = "Hello World!";
        String s2 = "I'm a new Java programmer!";

        System.out.println(s1 + "\n" + s2);
    }
}
