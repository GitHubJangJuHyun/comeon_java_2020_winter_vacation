public class ComparisonOperator {

    public static void main(String args[]){
        int x = 3;
        int y = 4;
        System.out.println((x == y) +" ");
        System.out.println((x != y) +" ");
        System.out.println((x > y) + " ");
        System.out.println((x < y) + " ");
        System.out.println((x <= y) + " ");
    }
}
