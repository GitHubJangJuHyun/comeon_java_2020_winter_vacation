public class BooleanTest {
    public static void main(String args[]){
        boolean b;

        b = true;
        System.out.println("b : " + b);
        b = (1 > 2);
        System.out.println("b : " + b);
    }
}
